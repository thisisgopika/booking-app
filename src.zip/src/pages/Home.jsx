import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Home = () => {
  const [hotels, setHotels] = useState([]);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ name: '', location: '', price: '' });
  const [editingId, setEditingId] = useState(null);

  // ✅ Fetch hotels on load
  useEffect(() => {
    fetchHotels();
  }, []);

  const fetchHotels = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/rooms');
      setHotels(res.data);
    } catch (err) {
      console.error('Failed to fetch hotels:', err);
    }
  };

  // ✅ Handle form input changes
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // ✅ Add or Edit hotel
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await axios.put(`http://localhost:5000/api/rooms/${editingId}`, form);
      } else {
        await axios.post('http://localhost:5000/api/rooms', form);
      }
      setForm({ name: '', location: '', price: '' });
      setEditingId(null);
      fetchHotels();
    } catch (err) {
      console.error('Submit failed:', err);
    }
  };

  // ✅ Delete hotel
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/rooms/${id}`);
      fetchHotels();
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  // ✅ Load hotel data for editing
  const handleEdit = (hotel) => {
    setForm({ name: hotel.name, location: hotel.location, price: hotel.price });
    setEditingId(hotel._id);
  };

  // ✅ Filtered hotel list
  const filteredHotels = hotels.filter((hotel) =>
    hotel.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: '20px' }}>
      <h1>Hotel Booking CRUD</h1>

      {/* 🔍 Search Box */}
      <input
        type="text"
        placeholder="Search hotels..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ marginBottom: '20px', padding: '8px', width: '300px' }}
      />

      {/* 🏨 Hotel Form */}
      <form onSubmit={handleSubmit} style={{ marginBottom: '30px' }}>
        <input
          type="text"
          name="name"
          placeholder="Hotel Name"
          value={form.name}
          onChange={handleChange}
          required
        />
        <input
          type="text"
          name="location"
          placeholder="Location"
          value={form.location}
          onChange={handleChange}
          required
        />
        <input
          type="number"
          name="price"
          placeholder="Price"
          value={form.price}
          onChange={handleChange}
          required
        />
        <button type="submit" style={{ marginLeft: '10px' }}>
          {editingId ? 'Update Hotel' : 'Add Hotel'}
        </button>
      </form>

      {/* 📋 Hotel Cards */}
      {filteredHotels.map((hotel) => (
        <div
          key={hotel._id}
          style={{
            border: '1px solid #ccc',
            padding: '10px',
            marginBottom: '10px',
            borderRadius: '8px',
          }}
        >
          <h3>{hotel.name}</h3>
          <p>{hotel.location}</p>
          <p>₹{hotel.price}</p>
          <button onClick={() => handleEdit(hotel)}>Edit</button>
          <button
            onClick={() => handleDelete(hotel._id)}
            style={{ marginLeft: '10px', color: 'red' }}
          >
            Delete
          </button>
        </div>
      ))}
    </div>
  );
};

export default Home;


































// TODO: Add input box 
// TODO: filter hotels based on search 
// TODO: Display hotel cards

/*import React ,{useState} from 'react';

const Home = () => {
  
  const [search,setSearch] = useState("")
  const Hotel = [
     
    {id:1,name:"Sea View Resort",location:"Goa"},
    {id:2,name:"Mountain Retreat",location:"Manali"},
    {id:3,name:"City Lights Hotel",location:"Mumbai"}

  ];

  const filteredHotels = Hotel.filter(hotel =>hotel.name.toLowerCase().includes(search.toLowerCase()));
   
  return (
      <div style ={{ padding :'20px'}}>

        <h1>Hotels</h1>

        <input
          
          type = "text"
          placeholder = "Search hotels..."
          value ={search}
          onChange={(e) => setSearch(e.target.value)}
          style ={{marginBottom: '20px',padding:'8px',width :'300px'}}
    
        />

        {filteredHotels.map(hotel => 
           <div key = {hotel.id}  style = {{
              border: '1px solid #ccc' ,padding :'10px', marginBottom:'10px',
              borderRadius : '8px'

            }}>
              <h3>{hotel.name}</h3>
              <p>{hotel.location}</p>
           </div>
        )}

      </div>

   
  );
};

export default Home;*/