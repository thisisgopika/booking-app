const express = require("express"); // we import express, a node framework
const router = express.Router(); // using express router to build a mini app
const Room = require("../models/Room"); // import mongoose model so reading/writing can happen easily

// CREATE Room
router.post("/", async (req, res) => {
  try {
    const newRoom = new Room(req.body); // req.body contains room data from frontend
    const savedRoom = await newRoom.save(); // saves the room to MongoDB
    res.status(201).json(savedRoom); // if saved, return 201 response
  } catch (err) {
    console.error("Error in POST /rooms:", err);
    res.status(500).json({ error: err.message }); // error handler
  }
});

// GET All Rooms
router.get("/", async (req, res) => {
  try {
    const rooms = await Room.find(); // get all rooms from MongoDB
    res.json(rooms); // sends the list of rooms as a response
  } catch (err) {
    console.error("Error in GET /rooms:", err);
    res.status(500).json({ error: err.message });
  }
});

// UPDATE Room
router.put("/:id", async (req, res) => {
  try {
    const updatedRoom = await Room.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedRoom); // sends updated room back to the frontend
  } catch (err) {
    console.error(`Error in PUT /rooms/${req.params.id}:`, err);
    res.status(500).json({ error: err.message });
  }
});

// DELETE Room
router.delete("/:id", async (req, res) => {
  try {
    await Room.findByIdAndDelete(req.params.id); // delete by room ID
    res.json({ msg: "Room deleted" }); // response is a message
  } catch (err) {
    console.error(`Error in DELETE /rooms/${req.params.id}:`, err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router; // export so we can connect it in index.js
