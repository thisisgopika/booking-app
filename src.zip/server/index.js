const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");
const roomRoutes = require("./routes/rooms"); // ✅ Your room routes

dotenv.config(); // Load .env variables

const app = express();
app.use(express.json()); //without this req.body wont work
app.use(cors());

// 🔍 Debug log
console.log("🔁 Server starting...");
console.log("🌍 MONGO_URL:", process.env.MONGO_URL);

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URL)
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ Mongo Error:", err));

// Mount auth routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/rooms", require("./routes/rooms"));


// Test route
app.get("/", (req, res) => {
  res.send("API is working ✅");
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
